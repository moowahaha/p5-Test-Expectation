package Test::Expectation::Positive;

    use base 'Test::Expectation::Base';

1;

