package Monkey;
    sub banana {
    }

    sub eat {
        banana();
    }

    sub focus {
    }

    sub look {
        focus('lady monkey');
    }

    sub swing {
    }

    sub fight {
        swing();
    }

    sub itch {}

    sub scratch {
        itch('bite');
    }
1;

